-- SUBQUERIES

    -- SINGLE ATOMIC VALUE (1 row, 1 col) - single row SQ
    -- LIST OF VALUES (N rows, 1 col) - multirow SQ
    -- TABLE DATA (N rows, M cols) - table data SQ
    -- inline SQ
    -- corelated SQ

    -- CTE (common table expressions)
    -- OPERATORS FOR MULTIROW SQ (ALL, ANY, EXISTS)


-- Write a SQL query to find all employees who work in same department as "Joshua Patel".

select * from hr.employees where department_id=(
    select department_id from hr.employees where first_name='Joshua' and last_name='Patel'
);

-- Write SQL query to find the employees who has same job_id as of Kimberely Grant.

select * from hr.employees where job_id=(
select job_id from hr.employees where first_name='Kimberely' and last_name='Grant');


-- Write SQL query to find all employees who earn more than Den.
select first_name from hr.employees where salary>(
    select salary from hr.employees where first_name='Den'
);

-- Write SQL query to find the job_id from employees table where salary earned is more than highest salary earned
    -- by employees who work as 'XY_MAN' job role where XY represents job code and _MAN is manager.

select distinct job_id from hr.employees where salary>(
    select max(salary) from hr.employees where job_id like '__\_MAN' escape '\'
);

-- Write SQL qeury to find employees who are also managers.

-- SQ => returns list (N rows, 1 col) => multirow SQ.
-- IN, ANY, ALL


select employee_id, first_name, last_name from hr.employees 
    where employee_id IN (
        select distinct manager_id from hr.employees
    );


-- Write SQL qeury to display names of all departments which has employee records in employee table.

-- 1. names of departments, which is available in departments table only
    select department_name from hr.departments;
-- 2. departments used in employee table, we only have dept_id on emp table
    select distinct department_id from hr.employees;

select department_name from hr.departments where department_id IN (
    select distinct department_id from hr.employees
);

-- Write SQL query to find the employee who earnmore than ANY manager in company.

select * from hr.employees where salary >ANY (
    select distinct salary from hr.employees where employee_id IN (select distinct manager_id from hr.employees)
) and employee_id not IN(select distinct manager_id from hr.employees where manager_id is not null);

-- Write SQL qeury to find employees who earn less than all the managers.

select * from hr.employees where salary < ALL(
    select distinct salary from hr.employees where employee_id IN(
        select distinct manager_id from hr.employees where manager_id is not null
    )
);

--

-- Write SQL qeury to find the employees who are highest salary earner in their respective department.

-- HINT: use analytical function


select first_name, last_name from(
    select first_name, last_name, salary, department_id,
    dense_rank() over(partition by department_id order by salary desc) as drnk
    from hr.employees
) where drnk=1;


-- corelated subquery

select first_name, last_name, department_id from hr.employees e
    where salary=(
        select max(salary) from hr.employees where department_id=e.department_id
    );

-- Write SQL qeury to find the employees who earn second highest salary in company.

select first_name, last_name, salary from hr.employees where salary=(
select max(salary) from(
select * from hr.employees where salary<(
    select max(salary) from hr.employees
)));

select * from (
select first_name, last_name, salary,
dense_rank() over(order by salary desc) as drnk from hr.employees)
where drnk=2;

select first_name, last_name, salary from hr.employees e
 where 1=(
    select count(distinct salary) from hr.employees where salary>e.salary
 );


-- Find all employees who earn more than avg of company
select first_name from hr.employees where salary>(
    select avg(salary) from hr.employees
);
-- Find all employees whose salary is least in their department
select first_name, last_name from (
    select first_name, last_name, dense_rank() over(partition by department_id order by salary) as drnk
         from hr.employees
) where drnk=1;
-- Find all employees who earn less than avg salary of their department
select first_name, last_name from hr.employees e where salary<(
    select avg(salary) from hr.employees where department_id=e.department_id
);
-- Find all employees whose has same or more experience than Neena

select first_name, last_name from hr.employees
    where sysdate-hire_date>=(
            select sysdate-hire_date from hr.employees where first_name='Neena'
    );


-- Inline subquery

-- write sql query that compares salary of each person with max salary of company

select first_name, last_name, salary, (select max(salary) from hr.employees) as mxsal
    from hr.employees;

--
select NVL(department_id, 900), count(*), sum(salary),
round((sum(salary)/(select sum(salary) from hr.employees))*100,2) as dept_percent
from hr.employees
group by department_id
order by department_id;

-- 
select 
    concat(e.first_name, ' ', e.last_name) as fullname, 
    NVL(m.first_name, 'No Manager') as manager
    from hr.employees e LEFT JOIN hr.employees m
    ON e.manager_id=m.employee_id
    where e.salary>(select avg(salary) from hr.employees)
    order by e.employee_id;

--
select 
    first_name, last_name,
    to_char(hire_date, 'DD-MON-YYYY') as hire_dt,
    replace(lower(concat(substr(first_name,1,1), last_name) || '@domain.com'), ' ', '') as email
    from hr.employees;

-- EXISTS operator
    -- if subquery returns atleast 01 record, then exists will return logical True state
    -- if q=subquery does not have any record, empty set, then exists will return False

-- Write SQL query to display all employees of department 30 if only there exists some employee in dept 30
    -- who earn more than 10000

select * from hr.employees where department_id=30
    AND EXISTS (select * from hr.employees where department_id=30 and salary>10000);


-- CTE (common table expression)
    -- WITH clause

select * from hr.employees where salary>(
    select avg(salary) from hr.employees
);


WITH CTE(avgsal) as (select avg(salary) from hr.employees)
select first_name, last_name from hr.employees, CTE
    where salary>CTE.avgsal;

-- Write SQL query using WITH clause to find the employees who earn highest in their dept

WITH temptable as (select first_name, last_name, salary,
dense_rank() over(partition by department_id order by salary desc) as drnk
from hr.employees)

select first_name, last_name, salary
    from temptable where drnk=1;


WITH temp(sumsal) as (select sum(salary) from hr.employees)
select department_id, count(*), sum(salary),
round((sum(salary)/temp.sumsal)*100, 2) as per_dept
from hr.employees, temp
group by department_id, temp.sumsal
order by department_id;

-- VIEWS
    -- virtual tables
    -- do not store data
    -- views => 1. materialised, 2. non-materialised (read-only)
    -- 1. simple view => created using single table or simple combination of 2 or more tables
    -- simple views can allow DML Ops
    -- 2. complex views => created using complex joins/SQ (may or may not allow DML)
    -- A view explicitly defined as READ ONLY will not allow DML Ops

-- 
create view emp30 as select eid, fname, lname, salary
    from emp where dept=30;

select * from emp30;

select eid, fname, lname, salary from emp where dept=30; 

insert into emp30 values(999, 'prateek','lnu', 900);
commit;

update emp30 set salary=salary/100;

delete from emp30 where salary>50;

-- complex view

create view sales_prod as select s.sales_id, s.sales_date, p.pdesc, p.price
    from sales s JOIN products p ON s.prod_id=p.pid;

select * from sales_prod;

select * from products;

update products set price=90 where pdesc='milk';


-- READ ONLY VIEW

create view emp110 as select eid, fname, lname, salary
    from emp where dept=110 WITH READ ONLY;

select * from emp110;

update emp set salary=salary/1000 where dept=110;

select * from user_views;

-- Create a view for emp dashboard displaying summaries like count, sum salary, avg salary etc.

create view emp_dash as select count(*) as emp_count, sum(salary) as tot_sal, avg(salary) as avg_sal,
    count(distinct dept) as depts from emp;

select * from emp_dash;

-- Temporary Tables
    -- auto truncate data once user session ends/expires
    -- used for temporary recording of data and processing

-- LOCAL => related to single user
-- GLOBAL => shared between multiple users

create global temporary table emp80(eid int, fname varchar2(20), lname varchar2(20), salary int);

insert into emp80 values(101, 'prateek','vashishtha', 20000);
insert into emp80 values(102, 'amit','sharma', 30000);
insert into emp80 values(103, 'simant','setu', 10000);
insert into emp80 values(104, 'ritesh','mukherjee', 40000);
alter table emp80 add new_sal int not null;
update emp80 set salary=salary*1.5;
update emp80 set new_sal=salary+5000;
select * from emp80;

desc emp80;

-- SET OPERATORS
    -- UNION, UNION ALL, INTEREST, MINUS

-- UNION => combine records from 2 or more data sets without duplicates.

select employee_id, first_name, last_name, salary, department_id, manager_id 
    from hr.employees where department_id=30
UNION
select employee_id, first_name, last_name, salary, department_id, manager_id 
    from hr.employees where department_id=20;

--

select employee_id, first_name, last_name, salary, department_id, manager_id 
    from hr.employees where department_id=30
UNION
select employee_id, first_name, last_name, salary, department_id, manager_id 
    from hr.employees where salary=3100;

-- UNION ALL => same as UNION but allow repetition/duplicate records

select employee_id, first_name, last_name, salary, department_id, manager_id 
    from hr.employees where department_id=30
UNION ALL
select employee_id, first_name, last_name, salary, department_id, manager_id 
    from hr.employees where salary=3100;

-- INTERSECT
select employee_id, first_name, last_name, salary, department_id, manager_id 
    from hr.employees where department_id=30
INTERSECT
select employee_id, first_name, last_name, salary, department_id, manager_id 
    from hr.employees where salary=3100;

-- MINUS

select employee_id, first_name, last_name, salary, department_id, manager_id 
    from hr.employees where department_id=30
MINUS
select employee_id, first_name, last_name, salary, department_id, manager_id 
    from hr.employees where salary=3100;

select employee_id, first_name, last_name, salary, department_id, manager_id 
    from hr.employees where department_id=30
MINUS
select employee_id, first_name, last_name, salary, department_id, manager_id 
    from hr.employees where department_id=30;


-- EXPLAIN PLAN
 EXPLAIN PLAN FOR
 select e.employee_id, e.first_name, e.last_name, e.salary, e.department_id, e.manager_id, m.first_name as mgr
 from hr.employees e LEFT JOIN hr.employees m
 ON e.manager_id=m.employee_id order by e.employee_id;
 select * from table(DBMS_XPLAN.DISPLAY);

-- SEQUENCE
    -- used to generate numeric values in specified sequence
    -- are independent objects and are not associated to any tables/view etc
    -- sequences can be shared to multiple table/views.

create sequence myseq 
    START WITH 10
    INCREMENT BY 1
    MAXVALUE 15
    MINVALUE 5
    CYCLE
    NOCACHE;

select myseq.NEXTVAL from dual;
select myseq.currval from dual;

insert into products values(myseq.NEXTVAL, 'apple', 295);

select * from product_info;

-- RENAME
    -- RENAME <object> to <new_name>;

rename products to product_info;