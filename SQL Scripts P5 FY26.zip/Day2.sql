-- CONSTRAINTS => NOT NULL, DEFAULT, UNIQUE, CHECK, PRIMARY KEY, FOREIGN KEY

-- foreign key

-- parent table
drop table products;
drop table sales;

create table products(pid int primary key, pdesc varchar2(20), price number(8,2));

insert into products values(401, 'milk', 70);
insert into products values(402, 'bread', 55);
insert into products values(403, 'curd', 40);
insert into products values(404, 'cheese', 145);
insert into products values(405, 'butter', 128);

select * from products;


-- child table
create table sales(sales_id int primary key, sales_date date, 
        sales_qty int not null, 
        prod_id int,
        CONSTRAINT prod_id_fk foreign key (prod_id) references products(pid)
        ON DELETE CASCADE);

insert into sales values(9001, '10-Sep-25', 5, 402);
insert into sales values(9002, '10-Sep-25', 12, 401);
insert into sales values(9003, '11-Sep-25', 10, 402);
insert into sales values(9004, '11-Sep-25', 2, 405);
insert into sales values(9005, '11-Sep-25', 1, 404);
insert into sales values(9006, '11-Sep-25', 15, 401);
insert into sales values(9007, '12-Sep-25', 7, 402);
insert into sales values(9008, '12-Sep-25', 1, 405);
insert into sales values(9009, '12-Sep-25', 6, 404);

select * from sales;

-- delete product
delete from products where pid=402;

create table demo(demo_id int,
                demo_desc varchar2(20) not null,
                demo_style char(2) unique);

ALTER table demo add constraint demo_id_pk primary key (demo_id);

ALTER table demo drop unique(demo_style);

ALTER table demo modify demo_desc null;

ALTER table demo drop constraint demo_id_pk;

desc demo;

-- enabling and disabling constraints
create table demo2(demo_id int,
                demo_desc varchar2(20) unique,
                demo_style int not null,
                constraint demo_id_pk primary key (demo_id));

insert into demo2 values(101, 'demo103', 30);

select * from demo2;

ALTER table demo2 disable constraint demo_id_pk;

ALTER table demo2 enable constraint demo_id_pk;

update demo2 set demo_id=103 where demo_style=30;

-- INDEXES

create table emp(eid int, fname varchar2(20), lname varchar2(20), salary int, dept int);

insert into emp select employee_id, first_name, last_name, salary, department_id from hr.employees;


create index eid_idx on emp(eid);

create index dept_idx on emp(dept);

ALTER index dept_idx UNUSABLE;

ALTER index dept_idx REBUILD;

drop index dept_idx;


-- 

select * from hr.employees;

-- SYNONYM 

-- CREATE SYNONYM <syn-name> FOR <table>;

create synonym em for hr.employees;

select * from em;

update em set salary=salary+5000;

-- dropping a synonym => no effect on original table

drop synonym em;

select * from hr.employees;

-- dropping a original table => synonym will become invalid

-- QUESTIONS:
-- 1. write SQL query to find all employees who belongs to either department 30 or 110
select * from hr.employees where department_id=30 or department_id=110;
-- 2. write SQL query to find employees whose job_id has '_MAN' 
select * from hr.employees where job_id like '%\_MAN' ESCAPE '\';
-- 3. write SQL query to display distinct department ids from table
select distinct department_id from hr.employees;
-- 4. write SQL query to find the employee who is not assigned any department
select * from hr.employees where department_id is null;
-- 5. write SQL query to find the employees who earn commission with salary
select * from hr.employees where commission_pct is not null;
-- 6. write SQL query to show updated salary of all employees if given 25% hike
select first_name, salary, salary*1.25 from hr.employees;


-- ADVANCE SQL

-- FUNCTIONS => set of instructions to perform specific task
-- funcs are reusable, via func call.
-- accepts zero or more args, produces an output after pricessing.

-- Single row functions
-- character, general, numeric, conversion, date

-- characters functions => upper, lower, initcap, trim, ltrim, rtrim, replace, substr, instr, lpad, rpad, 
-- length, concat

-- length
select length('hello') from dual;

select first_name, length(first_name) as name_size from hr.employees;

-- upper and lower
select upper('welcome') from dual;
select lower('WELCOME') from dual;

select first_name, lower(first_name), upper(first_name) from hr.employees;

-- concat(str, str)
select concat('hello','world') from dual;

select concat('hello', 'world', 'dear', 'friends') from dual;

select concat(concat('hello','world'), 'friends') from dual;

select concat(first_name, ' ', last_name) from hr.employees;

-- substr(str, start_pos, no_of_chars) => returns a substring form main str

select substr('ORACLE SQL PROGRAMMING', 1, 6) from dual;

select substr('ORACLE SQL PROGRAMMING', 8) from dual;

select substr('ORACLE SQL PROGRAMMING', 8, 3) from dual;

select substr('ORACLE SQL PROGRAMMING', -11, 7) from dual;

select substr('ORACLE SQL PROGRAMMING', -11, -7) from dual;

-- INSTR(str, substr, offset) => return position of substr to search, 0 if not found

select INSTR('hello world', 'world') from dual;

select INSTR('hello world', 'wonder') from dual;

select INSTR('ABRAKADABRA', 'A') from dual;

select INSTR('ABRAKADABRA', 'A', 5) from dual;


-- INITCAP(str) => return str with first char as upper case letter for each word

select INITCAP('hello world') from dual;

select INITCAP('HELLO WORLD') from dual;

-- replace(str, substr, replace_str) 
select replace('hello', 'l', 'p') from dual;

select replace(first_name, 'a', '@') from hr.employees;

-- trim / ltrim / rtrim

select '    hello    ' from dual;

select trim('    hello    ') from dual;
select ltrim('    hello    ') from dual;
select rtrim('    hello    ') from dual;

select ltrim('@#$$@#@#$@$#@hello@$#$@#$#@$#@', '@#$') from dual;

select rtrim('@#$$@#@#$@$#@hello@$#$@#$#@$#@', '@#$') from dual;

-- lpad / rpad
select lpad('hello', 16, '#') from dual;
select rpad('hello', 16, '#') from dual;

select first_name, salary, lpad(salary, 8, '*') from hr.employees;


-- numeric function => round, abs, mod, trunc, pow

select abs(-465) from dual;

select round(3.1457809) from dual;

select round(3.5457809) from dual;

select round(3.1457809, 3) from dual;

select round(3.1457809, 3), trunc(3.1457809, 3) from dual;

select round(4.916789, 3), trunc(4.916789, 3) from dual;

select round(4.916789), trunc(4.916789) from dual;

-- mod(num, num)

select mod(59, 4) from dual;

-- power(a, b)
select power(2, 8) from dual;


select sin(56) from dual;

select cos(45) from dual;

select tan(45) from dual;

select sqrt(1221) from dual;

-- GENERAL FUNCTIONS
-- NVL, NVL2, nullif, coalesce, case, decode, regexp_like, regexp_replace

-- NVL(value, encoded_value) => does nothing if value is not null, else replace with encoded value

select NVL('hello', 'this is null') from dual;

select NVL(null, 'this is null') from dual;

select department_id, NVL(department_id, 666) from hr.employees;

-- NVL2(value, not_null_encode, null_encode)

select commission_pct, NVL2(commission_pct, 'NOT NULL', 'NULL VALUE') from hr.employees;

-- DECODE(value, match, match_encode, not_match_encode)

select first_name, decode(first_name, 'Steven', 1, 0) from hr.employees;

select job_id, decode(job_id, 'SA_REP', 'Sales Representative', 'Others') from hr.employees;


-- nullif(val1, val2) => returns null if val 1 and val2 are same, else return val1.

select nullif('hello','Hello') from dual;

select nullif('10-Sep-25', '10-Sep-25') from dual;

-- COALESCE(values list) => returns first non-null value from list of values;

select COALESCE(null, null, null, null, null, 7, null, 8,3,2,2,4,null) from dual;

select COALESCE(null, null, null, null, null) from dual;

select commission_pct, salary+commission_pct, salary, 
    COALESCE(commission_pct, salary+commission_pct, salary) from hr.employees;


-- CASE => similar to if-then-else 

select first_name, job_id,
CASE job_id
    when 'SA_REP' then 'SALES REPRESENTATIVE'
    when 'IT_PROG' then 'PROGRAMMER'
    when 'AD_PRES' then 'President'
    when 'AD_VP' then 'Vide President'
    when 'SA_MAN' then 'SALES MANAGER'
    else 'Others'
end as job_role
from hr.employees;


-- write SQL qeury to ddiplay names, salary of all employees along with salary type as LOW if salary is less than 
-- or equal to 8000 else if its higher than 8000 then display HIGH.

select first_name, salary, 
CASE when salary>=0 and salary<=8000 then 'LOW'
when salary>8000 then 'HIGH'
else 'INVALID'
end as salary_type
from hr.employees;

-- REGEXP_LIKE, and REGEXP_REPLACE

select first_name, last_name from hr.employees
    where regexp_like(first_name, '^St(ev|eph)en$');

select first_name, phone_number from hr.employees
    where regexp_like(phone_number, '[0-9]{2}.[0-9]+.+');


select country_name, regexp_replace(country_name, 'land', 'world') from hr.countries;


-- CONVERSION FUNCTIONS
-- character to numeric
-- numeric to character
-- character to date
-- date to character


select hire_date, to_char(hire_date, 'Day Month DD, YYYY HH:MI:SS') from hr.employees;

select first_name, salary, to_char(salary, '$999,999,999.99') as sal from hr.employees;

-- to_date

select to_date('September 20, 2025', 'Month DD, YYYY') from dual;

select to_date('20241107091749', 'YYYYMMDDHHMISS') from dual;

-- to_number()

select to_number('3.134') * power(3, 2) from dual;


-- DATE FUNCTIONS
-- months_between, add_months, next_day, last_day, trunc

-- trunc(date, 'truncate_level') => level=> Y|M|D|H|M|S
select trunc(to_date('10-Sep-25'), 'YYYY') from dual;

select trunc(to_date('10-Sep-25'), 'Mon') from dual;

select trunc(to_date('10-Sep-25 11:15:45', 'DD-Mon-YY HH:MI:SS'), 'YY') from dual;


-- months_between(date, date) => returns integer value of diff bet dates
select months_between('12-Sep-25', '30-Jan-25') from dual;

select hire_date, round(months_between(sysdate, hire_date)/12,2) as exp from hr.employees;

-- add_months(date, 6)
select add_months(sysdate, 180) from dual;


-- next_day(date, day) => date for next week day specified

select next_day(sysdate, 'Friday') from dual;

select next_day(sysdate, 'Friday') from dual;

-- last_day
select last_day(sysdate) from dual;

--

-- SYSDATE

select sysdate from dual;

select current_date from dual;

select current_timestamp from dual;

select systimestamp from dual;

select localtimestamp from dual;

-- Aggregate functions
-- sum, count, avg, max, min, stddev, variance

select count(*) from hr.employees;

select count(department_id) from hr.employees;

select count(commission_pct) from hr.employees;


select count(distinct department_id) from hr.employees;

select count(distinct department_id) from hr.departments;

-- sum
select sum(salary) from hr.employees;

select sum(salary) from hr.employees where department_id=80;

select count(*), sum(salary) from hr.employees where department_id=80;

-- max, min
select max(salary), min(salary) from hr.employees;

select count(*), sum(salary), min(salary), max(salary) from hr.employees where department_id=80;

-- avg
select avg(salary) from hr.employees;

select count(*), sum(salary), min(salary), max(salary), avg(salary) from hr.employees where department_id=80;


-- stddev, variance

select stddev(salary), variance(salary) from hr.employees;

--
-- Sorting Data
-- ORDER BY CLAUSE => sorts data in ascending order by default

select employee_id, first_name, salary, department_id 
    from hr.employees
    ORDER BY first_name DESC;

select employee_id, first_name, salary, NVL(department_id, 0)
    from hr.employees
    ORDER BY department_id;

select employee_id, first_name, salary, NVL(department_id, 0)
    from hr.employees
    ORDER BY NVL(department_id, 0);

select employee_id, first_name, salary, NVL(department_id, 0) as dept
    from hr.employees
    ORDER BY dept;

select employee_id, first_name, salary, department_id 
    from hr.employees
    ORDER BY salary desc;

select employee_id, first_name, salary, department_id 
    from hr.employees
    ORDER BY department_id, salary desc;

select employee_id, first_name, salary, department_id 
    from hr.employees
    ORDER BY 4, 3 desc;

-- Write SQL Query to find the employees whose last name is 'patel' and you are not
-- sure about the letters case.

select first_name, last_name from hr.employees
    where upper(last_name) = 'PATEL';

-- write SQL query to fetch data of top 5 salary earning employees when data is sorted
-- by salary in desc order.

select first_name, last_name, salary from hr.employees 
    order by salary desc fetch first 5 rows only;

-- fetching next 5 rows after a offset location

select first_name, last_name, salary from hr.employees 
    order by salary desc offset 10 rows fetch next 5 rows only;

select first_name, last_name, salary from hr.employees 
    where rownum<6;

-- 
select employee_id, first_name, last_name, salary,
CASE when salary<=10000 then 'Eligible'
else 'Not Eligible' end as eligibility,
CASE when salary<=10000 then salary*1.1
else salary end as new_salary
from hr.employees;

--
select concat(first_name, last_name), length(concat(first_name, last_name))
    from hr.employees where upper(last_name) like '%A' or upper(last_name) like '%B';


select initcap(first_name) || initcap(last_name), length(last_name) + length(first_name)
    from hr.employees where initcap(substr(last_name, 1,1)) IN ('A', 'B', 'C');

--
select employee_id, first_name, salary, commission_pct,
CASE when commission_pct is null then 'No Data Found'
else to_char(commission_pct*1.2) end as new_comm
    from hr.employees;

select employee_id, first_name, salary, commission_pct,
NVL2(commission_pct, to_char(commission_pct*1.2), 'No Data Found')
    from hr.employees;