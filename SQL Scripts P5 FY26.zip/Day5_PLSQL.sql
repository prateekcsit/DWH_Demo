-- PLSQL
    -- programming logic + SQL query execution
    -- allow us to write PL with SQL queries

/*
conn=mysql.connector.connect(host, user, password, database, port)
cur=conn.cursor()
sql='select * from db.table;'
cur.execute(sql)
data=cur.fetchall()
for record in data:
    value=record['attribute']
    value=value*1.101
    new_value=value+hash(value)
    print(new_value)
*/

-- code is written in blocks => procedures
    -- procedures can be named or unnamed

DECLARE
    -- declaring variables, objects, cursor, record, etc
BEGIN
    -- to define programming logic constructs along with SQL queries
    EXCEPTION
    -- used to handle exceptions
END;


BEGIN
    dbms_output.put_line('Hello World from PLSQL.');
END;

DECLARE
    v_name varchar(20) :='Prateek';
BEGIN
    dbms_output.put_line('Welcome to PLSQL: '||v_name);
END;

DECLARE
    v_eid integer :=100;
BEGIN
    update emp set salary=0 where eid=v_eid;    
END;

DECLARE
    v_salary number default 0;
BEGIN
    select salary into v_salary from emp where eid=101;
    dbms_output.put_line('Salary for EID 101 is : '||v_salary);
END;

DECLARE
    v_salary number default 0;
    v_eid integer :=108;
BEGIN
    select salary into v_salary from emp where eid=v_eid;
    if v_salary<10000 then
        dbms_output.put_line('Salary is Low');
    else
        dbms_output.put_line('Salary is Fine');
    end if;
END;


-- 

DECLARE
    v_fname varchar(20);
    v_salary number;
BEGIN
    select fname, salary into v_fname, v_salary from emp where eid=108;
    dbms_output.put_line('FNAME: '||v_fname);
    dbms_output.put_line('SALARY: '||v_salary);
END;

--
DECLARE
    v_eid number:=108;
    v_rec emp%rowtype;
BEGIN
    select * into v_rec from emp where eid=v_eid;
    dbms_output.put_line(v_rec.fname);
    dbms_output.put_line(v_rec.lname);
    dbms_output.put_line(v_rec.salary);
END;

-- PLSQL LOOPS
    -- general, while, for

DECLARE
    v_counter number :=1;
BEGIN
    LOOP
    dbms_output.put_line('Counter: '||v_counter);
    v_counter:=v_counter+1;
        IF v_counter>5 THEN EXIT;
        END IF;
    END LOOP;
END;

DECLARE
    v_counter number :=1;
BEGIN
    LOOP
    dbms_output.put_line('Counter: '||v_counter);
    v_counter:=v_counter+1;
    EXIT WHEN v_counter>5;
    END LOOP;
END;

-- WHILE LOOP

DECLARE
    v_counter number :=1;
BEGIN
    WHILE v_counter<=5 LOOP
        dbms_output.put_line('Counter: '||v_counter);
        v_counter:=v_counter+1;
    END LOOP;
END;

-- FOR LOOP

DECLARE
    v_counter number :=1;
BEGIN
    FOR v_counter IN 1..5 LOOP
        dbms_output.put_line('Counter: '||v_counter);
    END LOOP;
END;

-- Write PLSQL code to display details of all employees bearing EID in range 101 to 110

DECLARE
    v_rec emp%rowtype;
    v_eid number;
BEGIN
    dbms_output.put_line('NAME | SALARY | DEPT');
    dbms_output.put_line('=================================');
    FOR v_eid IN 101..110 LOOP
        select * into v_rec from emp where eid=v_eid;
        dbms_output.put_line(v_rec.fname||v_rec.salary||' '||v_rec.dept);
    END LOOP;
END;

-- CURSOR
    -- 2D structure that can hold multiple records
    -- works like a pointer buffer memory
    -- iteratte over 1 record at a time
    -- and as soon as record is processed, it moves out of cursor memory
    -- cursor can be reused if its empty

-- CURSOR stages => declare > open > fetch > close

DECLARE
    v_rec emp%rowtype;
    CURSOR cur IS select * from emp where dept=30;
BEGIN
    OPEN cur;
    LOOP
        FETCH cur into v_rec;
        EXIT WHEN cur%NOTFOUND;
        dbms_output.put_line('-------------------------');
        dbms_output.put_line('First Name: '||upper(v_rec.fname));
        dbms_output.put_line('Last Name: '||upper(v_rec.lname));
        dbms_output.put_line('Salary: '||v_rec.salary*1000);
    END LOOP;
    CLOSE cur;
END;

-- STORED PROCEDURES
    -- procedures that are defined by a name
    -- can be static or dynamic
    -- static => procedures withour any input arguments
    -- dynamic => procedures with arguments

-- syntax:
/*
    create or replace procedure <procedure-name>(argument list) IS
    declare

    begin

    end;
*/

-- static stored procedures

create or replace procedure p1 IS
BEGIN
    update emp set salary=salary+1000;
END;

exec p1;

select * from emp;

-- Dynamic procedure
    -- ARGUMENTS TYPES =>  IN, OUT, IN OUT
    -- IN args => used for accepting inputs into proc
    -- OUT args => used for returning values computed in proc
    -- IN OUT => used as both IN and OUT type

create or replace procedure p2(p_eid IN emp.eid%type) is
    v_salary emp.salary%type;
BEGIN
    select salary into v_salary from emp where eid=p_eid;
    dbms_output.put_line('Salary for '||p_eid||' is : '||v_salary);
END;

exec p2(101);

-- OUT TYPE ARGS

create or replace procedure p3(p_dept OUT emp.dept%type) IS
begin
    select dept into p_dept from emp where eid=100;
end;

declare
    v_dept number;
begin
    p3(v_dept);
    dbms_output.put_line('Department Number: '||v_dept);
end;

-- IN and also OUT type together

create or replace procedure p4(p_eid IN emp.eid%type, p_salary OUT emp.salary%type) is
v_salary emp.salary%type;
begin
    select salary into v_salary from emp where eid=p_eid;
    p_salary:=v_salary*1.2;
end;

declare
    v_newsal number;
begin
    p4(108, v_newsal);
    dbms_output.put_line('Salary after 20% hike will be: '||v_newsal);

end;

-- IN OUT type args
    -- can accept input and also same arg will be used to return output

create or replace procedure p5(p_text IN OUT varchar) is
begin
    p_text:=trim(upper(p_text));
end;

declare
    v_msg varchar(100) default '   hello world   ';
begin
    v_msg:='this is test message';
    p5(v_msg);
    dbms_output.put_line('UPDATED TEXT: '||v_msg);
end;


-- create dynamic procedure to enter record into emp table 
create or replace procedure insert_emp_record(p_eid number, p_fname varchar, p_lname varchar,
    p_salary number, p_dept number) is
begin
    insert into emp values(p_eid, p_fname, p_lname, p_salary, p_dept);
end;

exec insert_emp_record(9098, 'Saksham', 'Vashishtha', 56000, 90);

select * from emp where eid=9098;

-- Write PLSQL code to read all records from table emp for specific department number, taken as input argument
    -- form user and display the details of employees along with new salary that is computed using 
    -- formula as : new_salary = salary + (salary*0.2) if only salary is less than 10000 else, keep as it is

create or replace procedure read_data(p_eid IN emp.eid%type) is
v_new_salary number default 0;
v_rec emp%rowtype;
CURSOR cur is select * into v_rec from emp where eid=p_eid;
begin
    OPEN cur;
    LOOP
        FETCH cur into v_rec;
        EXIT WHEN cur%notfound;
        dbms_output.put_line('================');
        dbms_output.put_line('EID: '||v_rec.eid);
        dbms_output.put_line('FNAME: '||v_rec.fname);
        dbms_output.put_line('LNAME: '||v_rec.lname);
        dbms_output.put_line('SALARY: '||v_rec.salary);
        IF v_rec.salary<=10000 THEN
            v_new_salary:=v_rec.salary+ (v_rec.salary*0.2);
            dbms_output.put_line('NEW SALARY ELIGIBLE: '||v_new_salary);
        END IF;
    END LOOP;
    CLOSE cur;
end;

exec read_data(90);

-- FUNCTIONS => user defined functions (UDF)
    -- functions are special type of SP
    -- func must return a value
    -- func can also have arguments=> IN type only

create or replace function message return varchar is
begin
    dbms_output.put_line('Hello Wold from Function.');
    return 'This is first function code.';
end;

select message() from dual;

begin
    dbms_output.put_line(message());
end;

select * from emp where length(message())>10;

select upper(message()) from dual;


create or replace function validate_email(p_email IN varchar) return varchar is
v_check number default 0;
begin
    IF INSTR(p_email, '@')>0 THEN v_check:=v_check+1; END IF;
    IF LENGTH(SUBSTR(p_email, 1, INSTR(p_email, '@')))>4 THEN v_check:=v_check+1; END IF;
    IF INSTR(p_email, '.')>8 THEN v_check:=v_check+1; END IF;

    IF v_check=3 THEN return 1;
    ELSE return 0;
    END IF;
end;

select validate_email('hello@email.com') from dual;

-- Write PLSQL function code that accepts string as argument and converts it to upper case, then finds the length,
    -- and returns a string that is repetition of original string N times if N is length of string.

create or replace function replicate(p_text IN varchar) return varchar is
v_counter number:=1;
v_newtext varchar(100):='';
begin
    for v_counter in 1..length(p_text) loop
        v_newtext:=concat(concat(v_newtext,' '), p_text);
    end loop;
    return upper(v_newtext);
end;    

select replicate('hello') from dual;

-- TRIGGERS
    -- special type of SP
    -- invoked automatically on an event
    -- always associated to an event on some object like table
    -- types => BEFORE | AFTER => before event or after event triggers
    -- types => INSERT | UPDATE | DELETE => on events like insert.update.delete it will run
        -- BEFORE INSERT | AFTER UPDATE | AFTER DELETE

/*
CREATE OR REPLACE TRIGGER <TRIGGER-NAME>
{BEFORE | AFTER}
{INSERT | UPDATE | DELETE | INSERT OR UPDATE | UPDATE OR DELETE}
ON <TABLE-NAME>
FOR EACH ROW
DECLARE

BEGIN
    EXCEPTION

END;
*/

create sequence logseq start with 9001 increment by 1 nomaxvalue nominvalue nocycle nocache;

create table emplog(logid int primary key, logtext varchar(200), logstamp date);

create or replace trigger emp_update
after update on emp for each row
begin
    insert into emplog values(logseq.nextval, 'EMP table record '|| :old.eid ||' updated by '||user, sysdate);
end;

update emp set salary=salary+5000 where eid=101;

select * from emplog;

-- Create a trigger on emp table that will only allow the update of salary if the new salary value is more,
    -- else it will revert back to old salary value.

-- :OLD.SALARY   :NEW.SALARY
create or replace trigger check_salary
before update on emp for each row
begin
    IF :OLD.SALARY < :NEW.SALARY THEN :NEW.SALARY := :NEW.SALARY;
    ELSE :NEW.SALARY := :OLD.SALARY;
    END IF;
end;

update emp set salary=25000 where eid=9098;

select * from emp;





-- create delete log trigger to enter log in same logemp table
create or replace trigger emp_delete
after delete on emp 
for each row
begin
    insert into emplog values(logseq.nextval, 'EMP record '||:old.eid||' deleted by '||user, sysdate);
end;

delete from emp where eid=9099;

select * from emplog;


-- DISABLE /ENABLE triggers

delete from emp where eid=105;

ALTER trigger emp_delete DISABLE;

ALTER trigger emp_delete ENABLE;


select * from emplog;

ALTER table emp DISABLE ALL TRIGGERS;

ALTER table emp ENABLE ALL TRIGGERS;

-- DATA DICTIONARIES
    -- DBADMIN
    -- USER => table, column, synonym, sequence, index, procedure, function, trigger,
                -- view, temp table, 
    -- ALL

select * from user_tables;

select * from user_tab_columns;

select * from user_indexes;

select * from all_synonyms;

select * from user_sequences;

select * from user_views;

select * from user_procedures;

-- functions can function
-- procedures can call function
-- procedure can exec another procedure
-- function can not call a procedure (IMP)

drop table customer CASCADE CONSTRAINTS;
drop table flight CASCADE CONSTRAINTS;
drop table booking CASCADE CONSTRAINTS;

create table customer(
custid varchar2(5) primary key check(custid like 'C%'),
custname varchar2(10));

create table flight(
flightid varchar2(5) primary key check (flightid like 'F%'),
flightname varchar2(15),
flighttype varchar2(20) check (flighttype in ('Domestic','International')),
source varchar2(15),
destination varchar2(15)
);

Alter table flight modify flightname varchar2(20);

create table booking(
bookingid number primary key,
flightid varchar2(5) references flight(flightid),
custid varchar2(5) references customer(custid),
travelclass varchar2(30) check(travelclass in('Business','Economy')),
flightcharge number,
bookingdate date
);

insert into customer values('C301','John');
insert into customer values('C302','Sam');
insert into customer values('C303','Robert');
insert into customer values('C304','Albert');
insert into customer values('C305','Jack');

insert into flight values('F101','Spice Jet Airlines','Domestic','Mumbai','Kolkata');
insert into flight values('F102','Indian Airlines','International','Delhi','Germany');
insert into flight values('F103','Deccan Airlines','Domestic','Chennai','Bengaluru');
insert into flight values('F104','British Airways','International','London','Italy');
insert into flight values('F105','Swiss Airlines','International','Zurich','Spain');


insert into booking values(201,'F101','C301','Business',12000,'22-Mar-18');
insert into booking values(202,'F105','C303','Business',30000,'17-May-18');
insert into booking values(203,'F103','C302','Economy',3000,'23-Jun-18');
insert into booking values(204,'F101','C302','Economy',10000,'12-Oct-18');
insert into booking values(205,'F104','C303','Business',25000,'16-Jan-19');
insert into booking values(206,'F105','C301','Business',30000,'22-Jan-19');
insert into booking values(207,'F104','C304','Economy',22000,'16-Feb-19');
insert into booking values(208,'F101','C304','Business',12000,'18-Sep-19');


select * from customer;
select * from flight;
select * from booking;