-- JOINING MULTIPLE TABLES
 -- JOINS => implicit, explicit
 -- Explicit Joins => Cross Join, Natural Join, Inner Join, Left Outer Join,
    -- Right Outer Join, Full Outer Join
 -- Types: equi joins, non-equi joins, self joins

-- Example:

select e.employee_id, e.first_name, e.department_id, d.department_name from hr.employees e, hr.departments d;

-- 107 * 27 => CROSS JOIN (implicit)- cartesian product

select e.employee_id, e.first_name, e.department_id, d.department_name 
    from hr.employees e CROSS JOIN hr.departments d;

-- NATURAL JOIN

select * from hr.employees NATURAL JOIN hr.departments;

-- impplicit inner join
select e.employee_id, e.first_name, e.department_id, d.department_name 
    from hr.employees e, hr.departments d
    where e.department_id=d.department_id;

-- explicit inner join
select e.employee_id, e.first_name, e.department_id, d.department_name 
from hr.employees e INNER JOIN hr.departments d
ON e.department_id=d.department_id;

-- LEFT OUTER JOIN
select e.employee_id, e.first_name, e.department_id, d.department_name 
from hr.employees e LEFT OUTER JOIN hr.departments d
ON e.department_id=d.department_id;

-- RIGHT OUTER JOIN
select e.employee_id, e.first_name, e.department_id, d.department_name 
from hr.employees e RIGHT OUTER JOIN hr.departments d
ON e.department_id=d.department_id;

-- FULL OUTER JOIN
select e.employee_id, e.first_name, e.department_id, d.department_name 
from hr.employees e FULL OUTER JOIN hr.departments d
ON e.department_id=d.department_id;

-- LOJ
select e.employee_id, e.first_name, e.department_id, d.department_name 
from hr.employees e , hr.departments d
where e.department_id=d.department_id(+);

-- ROJ
select e.employee_id, e.first_name, e.department_id, d.department_name 
from hr.employees e , hr.departments d
where e.department_id(+)=d.department_id;

-- NON-EQUI JOINS

create table salgrade(grade char(1) primary key,
                        minsal int, maxsal int);

insert into salgrade values('A', 2000, 5000);
insert into salgrade values('B', 5001, 10000);
insert into salgrade values('C', 10001, 15000);
insert into salgrade values('D', 15001, 20000);
insert into salgrade values('E', 20001, 25000);

select * from salgrade;

select e.employee_id, e.first_name, e.salary, g.grade
    from hr.employees e JOIN salgrade g
    on e.salary between g.minsal and g.maxsal
    order by e.employee_id;


-- 
select e.employee_id, e.first_name, e.salary, j.job_title
from hr.employees e JOIN hr.jobs j
on e.salary between j.min_salary and j.max_salary;


-- Write SQL query to display employee details along with name of manager for 
-- each employee

-- SELF JOIN
select e.employee_id, e.first_name, e.last_name, m.first_name as manager
from hr.employees e JOIN hr.employees m
ON e.manager_id=m.employee_id order by e.employee_id;

-- Write SQL query to display employee name, employee department name, city and country of work.

select e.employee_id, e.first_name, d.department_name, l.city, c.country_name
from hr.employees e 
JOIN hr.departments d ON e.department_id=d.department_id
JOIN hr.locations l ON d.location_id=l.location_id
JOIN hr.countries c ON l.country_id=c.country_id;

-- GROUPING DATA

select department_id, avg(salary) from hr.employees 
group by department_id;

select department_id, count(*), sum(salary), avg(salary), max(salary), min(salary) from hr.employees 
group by department_id;

-- filtering based on groups

select department_id, avg(salary) from hr.employees 
group by department_id
having avg(salary)>8000;


select department_id, round(avg(salary)) as avgsal 
from hr.employees 
where department_id is not null
group by department_id
having avg(salary)>8000
order by department_id;


-- group by on multiple columns

select NVL(department_id, 0), job_id, count(*)
from hr.employees
group by department_id, job_id
order by department_id;

-- Write SQL qeury to find the job_id wise avg salary.
select job_id, avg(salary) from hr.employees group by job_id;
-- Write SQL query to find the maximum salary for each department and project
    -- result in order of max salary in descending order
select department_id, max(salary) from hr.employees group by department_id order by max(salary) desc;
-- Write SQL query to find the job_id wise avg commission, and eliminate records
    -- for job_id that does not have commission
select job_id, avg(commission_pct) from hr.employees where commission_pct is not null group by job_id;

--

-- Analytical Functions
-- row_number, rank, dense_rank, lag, lead, listagg, first_value, last_value

-- window functions - they perform computations over a window of data at a time.

-- over() => used to create window partitions and size, order data within window
-- ROWS BETWEEN 
-- UNBOUNDED PRECEDING
-- UNBOUNDED FOLLOWING

-- row_number() => allocate row number to each record in window

select employee_id, first_name, salary, department_id,
ROW_NUMBER() OVER(order by salary desc) as row_number
from hr.employees;


select employee_id, first_name, salary, department_id,
ROW_NUMBER() OVER(partition by department_id order by salary desc) as row_number
from hr.employees;

-- RANK()

select employee_id, first_name, salary, department_id,
ROW_NUMBER() OVER(order by salary desc) as rn,
RANK() OVER(order by salary desc) as rnk
from hr.employees;

-- DENSE_RANK()
select employee_id, first_name, salary, department_id,
ROW_NUMBER() OVER(order by salary desc) as rn,
RANK() OVER(order by salary desc) as rnk,
DENSE_RANK() OVER(order by salary desc) as drnk
from hr.employees;

-- 
select employee_id, first_name, salary, department_id,
ROW_NUMBER() OVER(partition by department_id order by salary desc) as rn,
RANK() OVER(partition by department_id order by salary desc) as rnk,
DENSE_RANK() OVER(partition by department_id order by salary desc) as drnk
from hr.employees;


-- FIRST_VALUE()
select employee_id, first_name, salary, department_id,
FIRST_VALUE(salary) OVER(partition by department_id order by salary desc) as fv
from hr.employees;

-- LAST_VALUE()
select employee_id, first_name, salary, department_id,
FIRST_VALUE(salary) OVER(partition by department_id order by salary desc) as fv,
LAST_VALUE(salary) OVER(partition by department_id order by salary desc 
RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) as lv
from hr.employees;

-- write sql query to find cumulative sum of salaries for entire table
select employee_id, first_name, salary,
SUM(salary) OVER(order by salary ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as cumulative_sum
from hr.employees;

-- LAG(column, offset, def_value) => read and return value from table which is at lag of offset

select employee_id, first_name, salary,
LAG(salary, 2, 0) OVER(order by salary desc) as lg
from hr.employees;

-- LEAD(column, offset, def_value) => read and return value from table which is at lead of offset

select employee_id, first_name, salary,
LAG(salary, 2, 0) OVER(order by salary desc) as lg,
LEAD(salary, 2, 0) OVER(order by salary desc) as ld
from hr.employees;

-- LISTAGG(column, separator_symbol) => aggregate string values into single cell

select department_id, LISTAGG(first_name, ', ') WITHIN GROUP (order by first_name) as emp
from hr.employees group by department_id;


-- Hierarchical Retrieval

-- CONNECT BY PRIOR <col1>=<col2>

select employee_id, first_name, manager_id 
    from hr.employees 
    CONNECT BY PRIOR employee_id=manager_id;

-- LEVEL in built attribute that depicts level of depth in heirarchy

select employee_id, first_name, manager_id, LEVEL
    from hr.employees
    CONNECT BY PRIOR employee_id=manager_id;

-- START WITH

select employee_id, first_name, manager_id, LEVEL
    from hr.employees
    START WITH employee_id=100
    CONNECT BY PRIOR employee_id=manager_id;

select employee_id, first_name, manager_id, LEVEL
    from hr.employees
    START WITH employee_id=100
    CONNECT BY PRIOR employee_id=manager_id
    ORDER SIBLINGS BY first_name;

-- traverse one specific branch

select employee_id, first_name, manager_id, LEVEL
    from hr.employees
    START WITH employee_id=108
    CONNECT BY PRIOR employee_id=manager_id
    ORDER SIBLINGS BY first_name;


-- restricting levels
select employee_id, first_name, manager_id, LEVEL
    from hr.employees
    where LEVEl<3
    START WITH employee_id=100
    CONNECT BY PRIOR employee_id=manager_id
    ORDER SIBLINGS BY first_name;

-- Bottom Up Traversal => CONNECT_BY_ROOT

select first_name "Employee", CONNECT_BY_ROOT first_name "Manager",
    LEVEL-1 "Pathlength", SYS_CONNECT_BY_PATH(first_name, '/') "Path"
    from hr.employees where LEVEL>1 and department_id=110
    CONNECT BY PRIOR employee_id=manager_id
    ORDER BY "Employee", "Pathlength", "Manager", "Path";


-- Consider a table subscription with following schema:
    /* SUBSCRITPION(
        sub_id integer primary key,
        sub_type varchar2(10) not null,
        sub_start_date date not null,
        sub_end_date date default (sub_start_date+365) not null,
        customer_id integer not null foreign key
    );     */
-- Wite SQL query to find the customers whose subscription is still active
-- Write SQL query to find customers whose subscription is going to end in 
    -- 30 days or less