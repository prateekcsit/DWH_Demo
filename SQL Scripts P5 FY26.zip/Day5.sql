-- General Function Revisited
    -- character => upper, lower, initcap, length, replace, trim, ltrim, rtrim, lpad, rpad, concat, instr, substr
    -- numeric => round, abs, trunc, sin, cos, tan, sqrt, power, 
    -- conversion => to_char(), to_number(), to_date()
    -- date => months_between, add_months, last_day, next_day, trunc
    -- general functions => NVL, NVL2, COALESCE, CASE, DECODE, REGEXP_LIKE, REGEXP_REPLACE

    -- NVL(column, null_decode)

    select commission_pct, NVL(commission_pct, 0) from hr.employees;

    -- NVL2(column, non_null_decode, null_decode)

        select commission_pct, NVL2(commission_pct, 'IT IS VALID', 'IT IS NULL') from hr.employees;

    -- COALESCE(list_values) => return first non null value from list

    select COALESCE(null, null, null, null, 78, null, null, 89, 90, 90) from dual;

        select COALESCE(commission_pct, salary+commission_pct, salary) from hr.employees;

    -- DECODE(value, decoded_value)

    select job_id, decode(job_id, 'SA_REP', 'Sales Representative') from hr.employees;

    -- CASE
    select job_id,
    CASE job_id
    when 'SA_REP' then 'Sales Representative'
    when 'SA_MAN' then 'Sales Manager'
    when 'IT_PROG' then 'IT Programmer'
    when 'AD_VP' then 'Vice President'
    else 'others' end as job_role
    from hr.employees;

    -- REGEXP_LIKE

    select first_name from hr.employees where REGEXP_LIKE(first_name, '^N[a-z]*a$');

    -- REGEXP_REPLACE

    select first_name, REGEXP_REPLACE(first_name, '^A[a-z]+a$', 'SPECIAL') from hr.employees;