-- DDL, DML, DCl, TCL, DQL

-- DDL => CREATE, ALTER, TRUNCATE, DROP

-- CREATE  -> table, view, procedure, function, trigger, sequence, synonym, temp table
-- indexes

CREATE TABLE student(stdid integer, fname varchar2(20), lname varchar2(20),
    course varchar2(20), fees number(8,2), joining_date date);

-- ALTER -> add column, update column details, rename column, remove a column
-- => add constraints, enable/disable constraiints. reomve constraints
-- add or remove indexes, enable or disable indexes, 
-- enable/disable triggers

desc student;

-- add column
ALTER table student ADD student_type varchar2(10);

-- modify column
ALTER TABLE student MODIFY student_type char(3);

-- rename column
ALTER TABLE student RENAME column student_type to student_status;

-- DROP a column
ALTER TABLE student DROP column student_status;

-- DML => insert, update and delete
-- INSERT

insert into student values(101, 'Prateek','Vashishtha','SQL', 21000, '15-Sep-25');


insert into student values(102, 'Simant','Setu','Java', 18000, '10-Sep-25');

insert into student(stdid, fname, course, fees) values(103, 'Varun','AWS', 35000);

-- SELECT

select * from student;

-- update => update existing records by using operator SET
UPDATE student SET lname='Jain' where stdid=103;

UPDATE student SET JOINING_DATE='27-Aug-25' where stdid=103;

-- DELETE 
DELETE from student; -- removes all records in student table

DELETE from student where stdid=102;

-- TRUNCATE => removes all records
TRUNCATE table student;

-- DROP => delete table structure
DROP table student;

-- TCL => transaction control => COMMIT, ROLLBACK

-- commit => DML op will be permanent in DB
-- rollback => DML op will be rolled back to last commited state

create table sample(sid integer, sname varchar2(20));

select * from sample;

update sample set sname='NEW_SAMPLE_101x' where sid=101;
commit;
update sample set sname='NEW_SAMPLE_X' where sid=101; 
rollback;

START TRANSACTION;
update student set sname='USELESS_SAMPLE' where sid=102;
savepoint s1;
update student set sname='USEFUL_SAMPLE' where sid=102;
savepoint s2;
rollback to s1;

-- delete rollback

delete from sample where sid=101;
rollback;

-- DCL => grant and revoke

-- create user
-- create user <username>@host identified by <password>;

create user 'developer'@'%' identified by 'test@123';

-- GRANT <privileges> on <resources> to <user>@host [with grant option];

grant insert, update on *.* to 'developer'@'%';

revoke update on *.* from 'developer'@'%';

grant all privileges on *.* to 'developer'@'%' with grant option;

flush privileges;

-- select statements
-- HR schema having employees and departments;

select * from hr.employees;

-- projection (column), filter (records/tuples) and join (cobining 2 or more tables)

select employee_id, first_name, salary from hr.employees;

select * from hr.employees where department_id=20;

select employee_id, first_name, salary, department_id 
    from hr.employees where department_id=30;

-- operators
    -- arithmetic => +, -, /, *
    -- comparison => <, >, <=, >=, =, <>, !=
    -- logical => and, or , not
    -- membership => IN, not IN, BETWEEN, LIKE
    -- null comparison => is, is not
    -- other => ALL, ANY, EXISTS, 

select first_name, salary, salary*2 as new_salary from hr.employees;

select first_name, salary, salary+(salary*0.1) as new_salary from hr.employees;

select first_name, salary from hr.employees where salary>15000;

select first_name, salary, commission_pct from hr.employees where commission_pct is not null;

select first_name, salary from hr.employees where salary between 2000 and 2500;

select first_name, salary from hr.employees where department_id IN (10,20,30);

select first_name, salary from hr.employees where department_id=10 or department_id=20;

select first_name, salary from hr.employees where department_id=30 and salary>10000;

-- like => % matches any number chars and _ that matches exactly 1 char

select first_name  from hr.employees where first_name like 'Ste%';

select first_name  from hr.employees where first_name like 'Ste__en';

select first_name  from hr.employees where first_name like 'A%n';

-- CONSTRAINTS

-- NOT NULL, DEFAULT

create table sample2(sid int NOT NULL, 
                    sname varchar2(20) DEFAULT 'SampleX');

insert into sample2 values(null, 'sample102');

insert into sample2(sid) values(102);

select * from sample2;

-- UNIQUE

drop table sample3;

create table sample3(sid int not null, 
                    sname varchar2(20),
                    CONSTRAINT sname_unq UNIQUE(sname));

                -- CONSTRAINT <constr-name> <constr-type> (col_name);

insert into sample3 values(102, 'sample101');

-- primary key

drop table sample4;

create table sample4(sid int,
                    sname varchar2(20),
                    CONSTRAINT sid_pk primary key (sid),
                    CONSTRAINT sname_unq_2 UNIQUE(sname));

insert into sample4 values(102, 'samplex3');

insert into sample4(sname) values('sample_new');


-- CHECK constraint
-- CHECK <expression> => check (age>=18)

create table sample5(
    sid int primary key,
    sname varchar2(20),
    stype char(3) check (stype IN ('I', 'II', 'III', 'IV', 'V')),
    sprice number(8,2)
    CONSTRAINT sprice_chk check(sprice>=0)
);

insert into sample5 values(101, 'sample101', 'IV', 100);


create table student(
    stdid int primary key,
    fname varchar2(20) not null,
    lname varchar2(20) default 'lnu' not null,
    dob date not null,
    course varchar2(10) check (course IN ('BBA', 'BCA', 'B.Tech', 'MCA', 'B.Arch')),
    fees number(8,2),
    adm_date date not null,
    adm_status char(1),
    CONSTRAINT adm_date_chk check (adm_date>dob+(18*365))
);

insert into student(stdid, fname, dob, course, fees, adm_date, adm_status) 
    values(901, 'pratek', '18-Nov-01', 'BCA', 200000, sysdate, 'N');

select * from student;